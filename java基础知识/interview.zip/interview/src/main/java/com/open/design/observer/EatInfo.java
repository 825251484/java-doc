package com.open.design.observer;

public class EatInfo extends AbstrackInfo {
    @Override
    public void message(){
        System.out.println("大家吃饭了！");
    }
}

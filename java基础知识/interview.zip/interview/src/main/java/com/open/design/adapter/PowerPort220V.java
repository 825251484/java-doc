package com.open.design.adapter;

public class PowerPort220V {
    //原有插头只能输出220V
    public void Output_220v(){
    }
}

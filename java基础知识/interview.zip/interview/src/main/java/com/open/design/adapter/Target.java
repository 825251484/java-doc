package com.open.design.adapter;

public interface Target {
    //将220V转换输出110V
    public void Convert_110v();
}

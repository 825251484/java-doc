package com.open.design.factory;

public interface Product {
    //查看产品详情
    void show();
}

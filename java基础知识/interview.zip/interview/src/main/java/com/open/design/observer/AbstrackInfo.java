package com.open.design.observer;

public abstract class AbstrackInfo {
    //被监听的对象
    private Clock clock;
    abstract void message();
}

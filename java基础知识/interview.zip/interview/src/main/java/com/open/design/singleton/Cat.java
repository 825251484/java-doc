package com.open.design.singleton;

public class Cat {
}

package com.open.design.staticproxy;

public interface IUserDao {
	void save();
}


package com.open.design.dynamicproxy;

// 接口
public interface IUserDao {
	void save();
}

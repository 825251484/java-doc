package com.open.design.observer;

public class SleepInfo extends AbstrackInfo{
    @Override
    public void message(){
        System.out.println("大家午睡了！");
    }
}
